---
name: "Dev Restaurant"
description: "A high-octane culinary design system for Dev Restaurant (Good Food | Good Mood), pairing deep slate surfaces with sizzling neon amber, chili red accents, and crisp modern typography."
---

## Overview

Dev Restaurant is an authentic dining and express delivery brand famous for its slogan 'Good Food | Good Mood'. The design language combines obsidian and carbon surfaces with rich warm amber, chili red accents, and crisp typography to highlight pure ghee preparations, tandoori starters, thalis, and curries.

## Colors

The color palette centers around deep carbon/obsidian surfaces, energetic Sizzle Amber as primary brand fuel, fiery Chili Red as secondary punch, and mint fresh delivery accents. High contrast ensures readability in low-light and high-pace delivery contexts.

```yaml
colors:
  primary: "#FF6B00"
  on-primary: "#121417"
  secondary: "#E63946"
  on-secondary: "#111111"
  accent: "#FFB703"
  on-accent: "#1A1A1A"
  surface: "#121417"
  on-surface: "#F3F4F6"
  surface-card: "#1C1F26"
  on-surface-card: "#F3F4F6"
  surface-muted: "#282C35"
  on-surface-muted: "#9CA3AF"
  border-subtle: "#2D323F"
  success: "#10B981"
  on-success: "#393939"
  light:
    primary: "#D95500"
    on-primary: "#161616"
    surface: "#FAFAFA"
    on-surface: "#111827"
  dark:
    primary: "#FF7A1A"
    on-primary: "#121417"
    surface: "#0D0F12"
    on-surface: "#F9FAFB"
```

## Typography

The typography pairing uses **Afacad Flux** for dynamic, geometric headlines, **Instrument Sans** for clean, highly legible body copy and pricing tiers, and **Source Code Pro** for culinary stats, order tracking IDs, and prep timer readouts.

```yaml
typography:
  display-lg:
    fontFamily: "Afacad Flux"
    fontSize: 52px
    fontWeight: 800
    lineHeight: 58px
    letterSpacing: -1px
  display-lg-mobile:
    fontFamily: "Afacad Flux"
    fontSize: 32px
    fontWeight: 800
    lineHeight: 38px
    letterSpacing: -0.5px
  headline-lg:
    fontFamily: "Afacad Flux"
    fontSize: 36px
    fontWeight: 700
    lineHeight: 44px
    letterSpacing: -0.5px
  headline-lg-mobile:
    fontFamily: "Afacad Flux"
    fontSize: 26px
    fontWeight: 700
    lineHeight: 32px
    letterSpacing: -0.25px
  headline-md:
    fontFamily: "Afacad Flux"
    fontSize: 24px
    fontWeight: 600
    lineHeight: 30px
    letterSpacing: -0.2px
  headline-sm:
    fontFamily: "Afacad Flux"
    fontSize: 20px
    fontWeight: 600
    lineHeight: 26px
  body-lg:
    fontFamily: "Instrument Sans"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 26px
  body-md:
    fontFamily: "Instrument Sans"
    fontSize: 15px
    fontWeight: 400
    lineHeight: 22px
  body-sm:
    fontFamily: "Instrument Sans"
    fontSize: 13px
    fontWeight: 400
    lineHeight: 18px
  mono-sm:
    fontFamily: "Source Code Pro"
    fontSize: 13px
    fontWeight: 500
    lineHeight: 18px
    letterSpacing: 0.5px
```

## Layout & Spacing

A fluid responsive grid model for mobile devices with a 12-column max 1280px container on desktop. Micro spacing built on a 4px/8px modular rhythm.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 64px
  page-margin: 20px
```

## Elevation & Depth

Surfaces use dark carbon containers with subtle 1px border outlines (`#2D323F`) and ambient warm orange back-glows for active order cards. Glassmorphism is used on floating navigation headers (`backdrop-blur-md bg-opacity-80`).

## Shapes

Shapes reflect precision and speed: buttons and food cards feature ergonomic `12px` and `16px` pill corners with full pill badges for quick dietary tags (Veg, Non-Veg, Chef Special, Prep Time).

```yaml
rounded:
  sm: 6px
  DEFAULT: 10px
  md: 14px
  lg: 18px
  xl: 24px
  full: 9999px
```

## Motion & Micro-interaction

Micro-interactions feel crisp, snappy, and tactile. Add-to-cart buttons animate quickly with instant state change; notification pills bounce smoothly.

```yaml
motion:
  state-change:
    duration: 120ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 240ms
    delay: 0ms
    timingFunction: cubic-bezier(0.16, 1, 0.3, 1)
  surface-exit:
    duration: 160ms
    delay: 0ms
    timingFunction: cubic-bezier(0.4, 0, 1, 1)
```

## Voice & Content Strategy

Punchy, appetizing, and tech-culinary savvy. Headline phrasing blends culinary delight with lightning delivery ("Dispatched in 22 mins, crafted like art"). Action buttons are clear and immediate: "Order Now", "Explore Menu", "Track Delivery".

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
